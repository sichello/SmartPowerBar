Energy Meter by John Clarke
============================================
EPE Magazine May 2007

Control your power costs with our intelligent energy meter.
This PIC 16F628-powered device lets you accurately measure
energy usage for individual appliances and even figures out 
what it costs to run them. 

Also has brownout protection to protect sensitive equipment from
voltage drops.

Displays on its LCD readout power in Watts, consumption in kWh, cost in � or $, 
brownout detection and power switching, and more!

Parts are available from the usual component sources. Please note
that EPE does not provide kits but many of the requirements can
be met by our advertisers.

The latest version of the software is available from
ftp://ftp.epemag.wimborne.co.uk/pub/PICS/Energy_Meter

Please refer to the EPE web site for details of ordering back issues, subscriptions etc.
http://www.epemag.wimborne.co.uk

Last updated 19th April 2007