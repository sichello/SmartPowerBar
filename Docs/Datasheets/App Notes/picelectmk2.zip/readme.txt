PIC-Electric Mk 2 by John Becker

Everyday Practical Electronics, February 2005

This highly versatile electricity usage/ cost monitor and logger
is an update of a version first published about nine years
earlier. 230V/ 110V  50 Hz/ 60Hz compatible.
Two channels available for monitoring, 6kW maximum per channel.
Logging capacity approx 68 hours at 1 minute sampling rate.
Serial output available for PC interface, for data storage on disk.
Allows subsequent analysis with Excel etc.

Free source code available for download from 
http://www.epemag.wimborne.co.uk/downloads.html

Parts are available from the usual component sources. Please note
that EPE does not provide kits but many of the requirements can
be met by our advertisers.

Please refer to the EPE web site for details of ordering back issues,
subscriptions etc.

http://www.epemag.wimborne.co.uk

Last updated 11th February 2005.